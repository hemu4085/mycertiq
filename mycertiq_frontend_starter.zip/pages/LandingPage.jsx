// TODO: Paste Landing Page code here
export default function LandingPage(){return (<div>Landing Page Placeholder</div>)}