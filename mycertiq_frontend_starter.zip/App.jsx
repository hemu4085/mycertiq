import React from "react";
import LandingPage from "./pages/LandingPage";
import Dashboard from "./pages/Dashboard";

export default function App() {
  // Switch this to <Dashboard /> once dashboard code is pasted
  return <LandingPage />;
}
